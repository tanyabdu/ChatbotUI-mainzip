import LunarCalendar from "../LunarCalendar";

export default function LunarCalendarExample() {
  return <LunarCalendar />;
}

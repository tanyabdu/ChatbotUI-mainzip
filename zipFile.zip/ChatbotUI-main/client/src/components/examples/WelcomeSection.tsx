import WelcomeSection from "../WelcomeSection";

export default function WelcomeSectionExample() {
  return <WelcomeSection />;
}
